# Models Folder
Place model artifacts here if you must (e.g., `model.pkl`).

**Recommended**: avoid committing large binaries. Consider Git LFS or store models in releases.
